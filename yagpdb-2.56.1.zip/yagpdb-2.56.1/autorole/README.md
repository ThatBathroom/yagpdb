# Autorole

Autorole provides the ability to give users roles on join.

Features:

 - Give a role right on join
 - Give a role after x amount of time
 - Require a certain role to give the role
 - Ignore people with certain roles
