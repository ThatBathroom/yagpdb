Basic makeshift api implementatino for patreon v2 api, only works for yags needs as i couldn't be arsed to add in all options and such.

Needed because v1 api dosen't suit my needs (cancelling a pledge, wile it was paid that month isnt handled by v1)