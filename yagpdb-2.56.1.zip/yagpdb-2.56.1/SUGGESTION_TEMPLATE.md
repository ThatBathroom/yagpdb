So you want to suggest something eh? Well you've come to the right place. This is a guide that will help you formulate a suggestion that is easy to understand and to implement.

First we will go to the issues page and create a suggestion **check that it hasn't been suggested yet.**

Next you are gonna want a title such as "Suggestion: Make the bot dance!" just something short that explains what you are trying to do.

Third you will need some sort of description  and maybe even a mockup of what you are trying to show, please dont suggest something stupid like add more responses for catfacts12!1! Thats something you can do yourself by forking the project and editing the file.

Need more help or don't understand this post? Come down to the [support server](https://discord.gg/4udtcA5) and we will help you out gladly. 
