Sharding orchestrator, see github.com/jonas747/dshardorchestrator for more details.

Stores the total shard number in redis in the key: dshardorchestrator_totalshards