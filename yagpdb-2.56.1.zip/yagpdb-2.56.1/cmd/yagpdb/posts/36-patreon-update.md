    {
        "author": "jonas747",
        "date": "5th Mar 2018",
        "title": "Need for funding"
    }

Since ad-networks are denying me and the amazon ads are not giving any return. I'm gonna start seriously looking for other places for funding, such as Patreon which i hadn't taken very seriously before

The patreon goals have therefor been updated: https://www.patreon.com/yagpdb

Quick run-down:

For **$1/month:** The patron role and access to the patron only channel.

For **$5/month:** Access to **priority support**

For **$10/month:** Access to the **monthly patron only giveaways** (which I'm gonna start holding soon), and the **Quality supporter** role and channel

For **$25/month:** Suggest and have me prioritize 1 relatively simple feature.

For **$50/month:** Suggest and have me prioritize 1 medium-sized feature.


For the 2 highest tiers you should contact me first if the only reason you're donating is if you want something added, as opposed to a bonus, because i may be working on something important.

The volunteer support has access to the monthly patron-only giveaways as well.

What differs from the priority support to the normal help and issues channel is that i have notifications on there and will generally help faster there. (Off course the volunteer support may help before me as well)

Generally suggestions and requests from support will weigh a lot more than everyone else, that doesn't mean i don't read them all though.
