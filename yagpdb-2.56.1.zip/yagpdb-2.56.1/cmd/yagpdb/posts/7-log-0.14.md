    {
        "author": "jonas747",
        "date": "22nd Sept 2016",
        "title": "Version 0.14"
    }

 - **Added streaming notifications plugin!** This plugin will allow you to give people currently streaming a role, and also send a announcement message in a channel
 - Large cleanups in backend
 - General improvements and fixes to the overall control panel site
 - Increased the max subreddit limit to 25
 - Set Max custom commands to 50
 - Auto deleting response now also auto deleted the trigger (Will need manage messages perms for this)
 - Reddit feed should be more reliable (Still needs some work before i would consider it 100% but it is getting there)
 - Added Catfacts command
 - Added advice command
 - Add workaround for panics occuring when doing stuff related with message timestamps after the bot has been running for a while (Added a workaround but need to add a proper fix...)
 - Send a panic message when a command triggers a panic (Something went terribly wrong)
 - Added option for the kick command to delete up to the 100 last messages of a user when kicked
