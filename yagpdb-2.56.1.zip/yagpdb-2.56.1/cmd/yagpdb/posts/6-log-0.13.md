    {
        "author": "jonas747",
        "date": "7th Sept 2016",
        "title": "Version 0.13"
    }

Small update with mosly bugfixes

 - Kick and ban commands now do hastebin upload
 - Fixed not being able to update subreddit in reddit feeds
 - Fixed commands not running in dm
 - Set default command prefix to `-`