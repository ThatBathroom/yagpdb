    {
        "author": "jonas747",
        "date": "24th Aug 2016",
        "title": "Version 0.12"
    }

 - **Topic** command that just gives you a conversation topic
 - You can now specify a direct message that gets sent to people that gets kicked and banned through the bot
